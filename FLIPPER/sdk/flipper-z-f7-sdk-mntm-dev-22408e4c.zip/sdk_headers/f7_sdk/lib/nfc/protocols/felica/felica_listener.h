#pragma once

#include "felica.h"
#include <lib/nfc/nfc.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct FelicaListener FelicaListener;

#ifdef __cplusplus
}
#endif
