#pragma once

#include <gui/canvas.h>
#include <stdint.h>

#define ASSET_PACKS_PATH EXT_PATH("asset_packs")

void asset_packs_init(void);
void asset_packs_free(void);
