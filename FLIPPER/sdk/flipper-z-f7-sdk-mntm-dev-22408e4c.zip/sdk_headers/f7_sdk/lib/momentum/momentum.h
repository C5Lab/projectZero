#pragma once

// Keep momentum.h for backwards compatibility and for SDK header

#ifdef __cplusplus
extern "C" {
#endif

#include "asset_packs.h"
#include "settings.h"

#ifdef __cplusplus
}
#endif
