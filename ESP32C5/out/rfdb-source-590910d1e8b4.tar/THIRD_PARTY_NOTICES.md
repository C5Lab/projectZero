# Third-Party Notices

The original source code within the `ESP32C5/` subproject is licensed under
Apache-2.0. This subproject-level license does not replace the MIT license at
the parent repository root; the parent repository remains licensed under MIT.
Files carrying their own notices retain those notices and are not relicensed
by the `ESP32C5/LICENSE`.

## RF database artifacts

The following database artifacts are separate runtime data files. They are not
embedded in the JanOS firmware image.

| Artifact | Runtime path | Data source | License | Corresponding source |
|---|---|---|---|---|
| `vendors.bin` | `/sdcard/lab/vendors.bin` | pinned Wireshark `epan/manuf-data.c`; Wifite3 behavior reference | GPL-2.0-or-later | matching `rfdb-source-<revision>.tar.zst` |
| `wps_pin.bin` | `/sdcard/lab/wps_pin.bin` | pinned Airgeddon `known_pins.db` and Default-WPS-PINs `pins.csv` | GPL-3.0-only | matching `rfdb-source-<revision>.tar.zst` |

Wifite3 v0.4.3 is credited as the behavior reference for longest-prefix vendor
lookup and ranked WPS candidates. JanOS does not copy its Python implementation.
Exact revisions and SHA-256 values are recorded in
`tools/rfdb/sources.lock.json` before a database is released.

### Wireshark vendor source

- Project: Wireshark
- Imported file: `epan/manuf-data.c`
- Revision: `0451baac5b807b69db16a8d027fb5f199cc0ad5a`
- Source SHA-256: `9e311f92985979b92c948949c20934120bbed7015fd5344f7999e91650532c87`
- License: `GPL-2.0-or-later`
- Transformation: parse the generated `/24`, `/28`, and `/36` tables; preserve
  the full vendor name; truncate names to 60 UTF-8 bytes; intern names; sort
  prefixes; encode the checksummed `JVND` v3 runtime artifact.
- Wifite3 role: behavioral reference for longest-prefix matching only.

Full license texts are available in:

- `LICENSES/Apache-2.0.txt`
- `LICENSES/GPL-2.0-only.txt`
- `LICENSES/GPL-2.0-or-later.txt`
- `LICENSES/GPL-3.0-only.txt`

