# Rebuilding the RF databases

This archive contains the exact locked inputs, generator scripts, license texts, and notices used for the separately distributed RF database artifacts.

Source lock SHA-256: `590910d1e8b4f3ef971e78f06488410f284bfe27ccad0a13d14474c51503f0d2`

1. Verify every file in `inputs/` against `sources.lock.json`.
2. Run the applicable generator from `generators/` using only those inputs.
3. Compare the generated artifact hash with the corresponding release hash.

The generators must not execute downloaded input data. Compression of this TAR is a packaging step and does not change the manifest.
