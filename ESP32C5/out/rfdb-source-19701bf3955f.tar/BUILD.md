# Rebuilding the RF databases

This archive contains the exact locked inputs, generator scripts, license texts, and notices used for the separately distributed RF database artifacts.

Source lock SHA-256: `19701bf3955ff8e091753f7e62528706d6373bf34ab65a2a24784448a0f2f262`

1. Verify every file in `inputs/` against `sources.lock.json`.
2. Run the applicable generator from `generators/` using only those inputs.
3. Compare the generated artifact hash with the corresponding release hash.

The generators must not execute downloaded input data. Compression of this TAR is a packaging step and does not change the manifest.
